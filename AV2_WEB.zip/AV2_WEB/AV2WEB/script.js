// Geselecteerde vaccinatiekaart
var geselecteerdeKaart = null;
var vaccinaties = [];

// --- DEEL 1: AUTOMATISCHE BEREKENING VAN LEEFTIJD ---
var veldGeboorte = document.getElementById('dataNascimento');
var veldJaren = document.getElementById('idadeAnos');
var veldMaanden = document.getElementById('idadeMeses');

function berekenLeeftijd() {
  var waarde = veldGeboorte.value;
  if (!waarde) {
    veldJaren.value = '';
    veldMaanden.value = '';
    updateAchterstalligeVaccins();
    return;
  }
  var delen = waarde.split('-');
  var geboorte = new Date(Number(delen[0]), Number(delen[1]) - 1, Number(delen[2]));
  var vandaag = new Date();
  var jaren = vandaag.getFullYear() - geboorte.getFullYear();
  var maanden = vandaag.getMonth() - geboorte.getMonth();
  if (vandaag.getDate() < geboorte.getDate()) maanden--;
  if (maanden < 0) { jaren--; maanden += 12; }
  if (geboorte > vandaag) {
    alert('De geboortedatum kan niet in de toekomst liggen.');
    veldGeboorte.value = '';
    veldJaren.value = '';
    veldMaanden.value = '';
    updateAchterstalligeVaccins();
    return;
  }
  veldJaren.value = jaren + (jaren === 1 ? ' jaar' : ' jaar');
  veldMaanden.value = maanden + (maanden === 1 ? ' maand' : ' maanden');
  updateAchterstalligeVaccins();
}
veldGeboorte.addEventListener('change', berekenLeeftijd);

function leeftijdInMaanden() {
  if (!veldGeboorte.value) return null;
  var p = veldGeboorte.value.split('-');
  var geboorte = new Date(Number(p[0]), Number(p[1]) - 1, Number(p[2]));
  var nu = new Date();
  return (nu.getFullYear() - geboorte.getFullYear()) * 12 + nu.getMonth() - geboorte.getMonth() - (nu.getDate() < geboorte.getDate() ? 1 : 0);
}

// --- DEEL 2: VALIDATIE VAN HET NEDERLANDSE BSN EN HET SUS-NUMMER ---
function alleenCijfers(tekst) {
  return String(tekst).replace(/[^0-9]/g, '');
}

// Het Nederlandse BSN bestaat uit 9 cijfers en gebruikt de elfproef:
// (9*a)+(8*b)+(7*c)+(6*d)+(5*e)+(4*f)+(3*g)+(2*h)-(1*i).
// Het resultaat moet deelbaar zijn door 11. Een BSN van 8 cijfers
// wordt links aangevuld met een nul. Deze controle bewijst niet dat
// het nummer daadwerkelijk is uitgegeven of bij een persoon hoort.
function validarBSN(tekst) {
  var bsn = alleenCijfers(tekst);
  if (bsn.length === 8) bsn = '0' + bsn;
  if (bsn.length !== 9 || /^0{9}$/.test(bsn)) return false;
  var gewichten = [9, 8, 7, 6, 5, 4, 3, 2, -1];
  var som = 0;
  for (var i = 0; i < 9; i++) som += Number(bsn[i]) * gewichten[i];
  return som % 11 === 0;
}

// CNS: modo simplificado para a demonstracao do projeto.
// Aceita qualquer sequencia de 15 digitos; nao confirma cadastro real no SUS.
function validarCartaoSUS(tekst) {
  var cns = alleenCijfers(tekst);
  return /^\d{15}$/.test(cns);
}
// Disponibiliza a funcao para testes no Console do navegador.
window.validarCartaoSUS = validarCartaoSUS;

// --- DEEL 3: VALIDATIE VAN HET KINDERFORMULIER ---
var formulier = document.getElementById('form-crianca');
formulier.addEventListener('submit', function(event) {
  event.preventDefault();
  var naam = document.getElementById('nomeCrianca').value.trim();
  var geboorte = veldGeboorte.value;
  var bsn = document.getElementById('cpfCrianca').value;
  var sus = document.getElementById('numeroSus').value;
  var ouder1 = document.getElementById('responsavel1').value.trim();
  if (!naam || !geboorte || !bsn.trim() || !sus.trim() || !ouder1) {
    alert('Vul alle verplichte velden (*) in.');
    return;
  }
  if (!validarBSN(bsn)) {
    alert('Het BSN is ongeldig. Controleer de 9 cijfers en de elfproef.');
    return;
  }
  if (!validarCartaoSUS(sus)) {
    alert('Het SUS-kaartnummer (CNS) is ongeldig. Het moet 15 geldige cijfers bevatten.');
    return;
  }
  document.getElementById('mensagem-cadastro').textContent = 'De gegevens van ' + naam + ' zijn gecontroleerd! U kunt de vaccinaties registreren en de kaart opslaan.';
});

// --- DEEL 4: VACCINATIEKALENDER LADEN EN KAARTEN MAKEN ---
fetch('vacinasSUS.json')
  .then(function(response) { if (!response.ok) throw new Error('JSON-bestand niet gevonden'); return response.json(); })
  .then(function(data) {
    vaccinaties = data.calendario_vaccinatie_kinderen_nl;
    var container = document.getElementById('lista-vacinas');
    for (var i = 0; i < vaccinaties.length; i++) {
      var vaccin = vaccinaties[i];
      var doses = dosesSplitsen(vaccin.leeftijd);
      for (var j = 0; j < doses.length; j++) {
        maakVaccinatiekaart(container, vaccin.vaccinatie, doses[j], vaccin.waarvoor, j + 1);
      }
    }
    updateAchterstalligeVaccins();
  })
  .catch(function(error) {
    console.log('Fout bij het laden van JSON:', error);
    document.getElementById('lista-vacinas').innerHTML = '<p>Kan vacinasSUS.json niet laden. Open het project met Live Server.</p>';
  });

function dosesSplitsen(tekst) {
  if (tekst.indexOf(';') !== -1) return [tekst];
  return tekst.replace(' en ', ', ').split(', ');
}

function leeftijdDoseInMaanden(tekst) {
  var t = tekst.toLowerCase();
  if (t.indexOf('geboorte') !== -1 || t.indexOf('geboren') !== -1) return 0;
  var bereik = t.match(/(\d+)\s*(?:tot|–|-)\s*(\d+)\s*jaar/);
  if (bereik) return Number(bereik[1]) * 12;
  var jaren = t.match(/(\d+)\s*jaar/);
  if (jaren) return Number(jaren[1]) * 12;
  var maanden = t.match(/(\d+)\s*maanden?/);
  if (maanden) return Number(maanden[1]);
  return null;
}

function maakVaccinatiekaart(container, naam, leeftijd, beschrijving, dosis) {
  var kaart = document.createElement('div');
  kaart.className = 'card-vacina';
  kaart.dataset.leeftijdMaanden = leeftijdDoseInMaanden(leeftijd) === null ? '' : leeftijdDoseInMaanden(leeftijd);
  kaart.innerHTML = '<span class="etiqueta-dose">Dosis ' + dosis + '</span>' +
    '<h3>' + naam + '</h3>' + '<p><strong>Leeftijd:</strong> ' + leeftijd + '</p>' +
    '<p class="status-texto">Status: Nog niet toegediend</p>' +
    '<p class="status-atraso escondido">Achterstallig: aanbevolen leeftijd is bereikt.</p>' +
    '<div class="detalhes-aplicacao-card escondido"></div>';
  kaart.addEventListener('click', function() { abrirVenster(kaart, naam, dosis, leeftijd, beschrijving); });
  container.appendChild(kaart);
}

// --- DEEL 5: MELDINGEN VOOR ACHTERSTALLIGE VACCINATIES ---
function updateAchterstalligeVaccins() {
  var leeftijd = idadeEmMaandenSafe();
  var kaarten = document.querySelectorAll('.card-vacina');
  for (var i = 0; i < kaarten.length; i++) {
    var kaart = kaarten[i];
    var vereisteLeeftijd = kaart.dataset.leeftijdMaanden;
    var achterstallig = leeftijd !== null && vereisteLeeftijd !== '' && leeftijd >= Number(vereisteLeeftijd) && !kaart.classList.contains('tomada');
    kaart.classList.toggle('atrasada', achterstallig);
    var label = kaart.querySelector('.status-atraso');
    if (label) label.classList.toggle('escondido', !achterstallig);
    var status = kaart.querySelector('.status-texto');
    if (status && !kaart.classList.contains('tomada')) status.textContent = achterstallig ? 'Status: Achterstallig' : 'Status: Nog niet toegediend';
  }
}
function idadeEmMaandenSafe() { return leeftijdInMaanden(); }

// --- DEEL 6: MODAAL VENSTER EN REGISTRATIE VAN TOEDIENING ---
var janela = document.getElementById('janela-detalhes');
var checkTomada = document.getElementById('check-tomada');
var camposAplicacao = document.getElementById('campos-aplicacao');
var inputDataAplicacao = document.getElementById('dataAplicacao');
var inputNumeroLote = document.getElementById('numeroLote');
var inputUnidadeAplicadora = document.getElementById('unidadeAplicadora');
var inputResponsavelAplicacao = document.getElementById('responsavelAplicacao');
var btnConfirmar = document.getElementById('btn-confirmar');
var btnFechar = document.getElementById('btn-fechar');

checkTomada.addEventListener('change', function() {
  camposAplicacao.classList.toggle('escondido', !checkTomada.checked);
});
function formatarData(dataISO) {
  if (!dataISO) return '';
  var p = dataISO.split('-');
  return p[2] + '-' + p[1] + '-' + p[0];
}
function abrirVenster(kaart, naam, dosis, leeftijd, beschrijving) {
  geselecteerdeKaart = kaart;
  document.getElementById('janela-titulo').textContent = naam;
  document.getElementById('janela-dose').textContent = 'Dosis ' + dosis;
  document.getElementById('janela-idade').textContent = leeftijd;
  document.getElementById('janela-descricao').textContent = beschrijving;
  checkTomada.checked = kaart.classList.contains('tomada');
  camposAplicacao.classList.toggle('escondido', !checkTomada.checked);
  inputDataAplicacao.value = kaart.dataset.dataAplicacao || '';
  inputNumeroLote.value = kaart.dataset.numeroLote || '';
  inputUnidadeAplicadora.value = kaart.dataset.unidadeAplicadora || '';
  inputResponsavelAplicacao.value = kaart.dataset.responsavelAplicacao || '';
  janela.classList.remove('escondido');
}

btnConfirmar.addEventListener('click', function() {
  if (!geselecteerdeKaart) return;
  var status = geselecteerdeKaart.querySelector('.status-texto');
  var details = geselecteerdeKaart.querySelector('.detalhes-aplicacao-card');
  if (checkTomada.checked) {
    var datum = inputDataAplicacao.value;
    var lot = inputNumeroLote.value.trim();
    var eenheid = inputUnidadeAplicadora.value.trim();
    var verantwoordelijke = inputResponsavelAplicacao.value.trim();
    if (!datum || !lot || !eenheid || !verantwoordelijke) {
      alert('Vul de datum, het batchnummer, de vaccinatielocatie en de naam van de zorgverlener in.');
      return;
    }
    geselecteerdeKaart.dataset.dataAplicacao = datum;
    geselecteerdeKaart.dataset.numeroLote = lot;
    geselecteerdeKaart.dataset.unidadeAplicadora = eenheid;
    geselecteerdeKaart.dataset.responsavelAplicacao = verantwoordelijke;
    geselecteerdeKaart.classList.add('tomada');
    status.textContent = 'Status: Toegediend ✓';
    details.innerHTML = '<strong>Datum:</strong> ' + formatarData(datum) + '<br><strong>Batch:</strong> ' + lot + '<br><strong>Locatie:</strong> ' + eenheid + '<br><strong>Zorgverlener:</strong> ' + verantwoordelijke;
    details.classList.remove('escondido');
  } else {
    geselecteerdeKaart.classList.remove('tomada');
    status.textContent = 'Status: Nog niet toegediend';
    details.innerHTML = '';
    details.classList.add('escondido');
    delete geselecteerdeKaart.dataset.dataAplicacao;
    delete geselecteerdeKaart.dataset.numeroLote;
    delete geselecteerdeKaart.dataset.unidadeAplicadora;
    delete geselecteerdeKaart.dataset.responsavelAplicacao;
  }
  janela.classList.add('escondido');
  updateAchterstalligeVaccins();
});
btnFechar.addEventListener('click', function() { janela.classList.add('escondido'); });

// --- DEEL 7: DE VACCINATIEKAART OPSLAAN ALS LOKAAL JSON-BESTAND ---
function opslaanAlsJSON() {
  var formulier = document.getElementById('form-crianca');
  if (!formulier.reportValidity()) return;
  // Hergebruik dezelfde documentcontroles voordat de kaart wordt geëxporteerd.
  var bsn = document.getElementById('cpfCrianca').value;
  var sus = document.getElementById('numeroSus').value;
  if (!validarBSN(bsn)) { alert('Het BSN is ongeldig. Controleer de elfproef.'); return; }
  if (!validarCartaoSUS(sus)) { alert('Het SUS-kaartnummer (CNS) is ongeldig.'); return; }
  var geregistreerdeVaccins = [];
  var kaarten = document.querySelectorAll('.card-vacina');
  for (var i = 0; i < kaarten.length; i++) {
    var k = kaarten[i];
    geregistreerdeVaccins.push({
      vaccinatie: k.querySelector('h3').textContent,
      dosis: k.querySelector('.etiqueta-dose').textContent,
      leeftijd: k.querySelector('p').textContent.replace('Leeftijd: ', ''),
      toegediend: k.classList.contains('tomada'),
      datum: k.dataset.dataAplicacao || null,
      batch: k.dataset.numeroLote || null,
      locatie: k.dataset.unidadeAplicadora || null,
      zorgverlener: k.dataset.responsavelAplicacao || null
    });
  }
  var gegevens = {
    land: 'Nederland',
    kind: {
      naam: document.getElementById('nomeCrianca').value.trim(),
      geboortedatum: veldGeboorte.value,
      leeftijdJaren: veldJaren.value,
      leeftijdMaanden: veldMaanden.value,
      bsn: alleenCijfers(bsn),
      susNummer: alleenCijfers(sus),
      wettelijkeVerantwoordelijke1: document.getElementById('responsavel1').value.trim(),
      wettelijkeVerantwoordelijke2: document.getElementById('responsavel2').value.trim()
    },
    vaccinaties: geregistreerdeVaccins,
    exportdatum: new Date().toISOString()
  };
  var bestand = new Blob([JSON.stringify(gegevens, null, 2)], { type: 'application/json;charset=utf-8' });
  var url = URL.createObjectURL(bestand);
  var link = document.createElement('a');
  link.href = url;
  link.download = 'vaccinatiekaart-' + (gegevens.kind.naam.replace(/[^a-z0-9_-]/gi, '_') || 'kind') + '.json';
  document.body.appendChild(link);
  link.click();
  document.body.removeChild(link);
  URL.revokeObjectURL(url);
  document.getElementById('mensagem-cadastro').textContent = 'De digitale vaccinatiekaart is opgeslagen als JSON-bestand.';
}
document.getElementById('btn-salvar').addEventListener('click', opslaanAlsJSON);
